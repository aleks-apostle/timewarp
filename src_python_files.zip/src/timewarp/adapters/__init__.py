"""Adapters to integrate Timewarp with external frameworks."""
